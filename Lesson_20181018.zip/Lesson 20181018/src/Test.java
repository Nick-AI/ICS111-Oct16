/**
 * A class to test the gradeAllStudents() method of the FairProfessor class
 * Makes 3 courses with 4 students each, and makes a FairProfessor who teaches these 3 courses.
 * Then makes the professor grade ALL the students in ALL the courses.
 * 
 * @author Camelia Lai
 *
 */
public class Test {

	public static void main(String[] args) {
		
		// Students in ICS 111
		Student smartStudent = new Student("Smarty", 5);
		Student okStudent = new Student("John C. GetDegrees", 3);
		Student studentWhoDidNotStudy = new Student("Ainokea", 1);
		Student studentWhoDidNotShowUp = new Student("Abby Absent", 0);
		
		// Make array of ICS 111 students
		Student[] students111 = {smartStudent, okStudent, studentWhoDidNotStudy, studentWhoDidNotShowUp};
		
		// Create ICS 111 course
		Course course1 = new Course("ICS 111", students111);
		
		// Students in ICS 211
		Student overAchiever = new Student("Albert", 5);
		Student bStudent = new Student("Barry B", 4);
		Student dStudent = new Student("Darry D", 2);
		Student lateStudent = new Student("Mardy Tardy", 0);
		
		// Make array of ICS 211 students
		Student[] students211 = {overAchiever, bStudent, dStudent, lateStudent};
		
		// Create ICS 211 course
		Course course2 = new Course("ICS 211", students211);
		
		// Students in ICS 311
		Student cheatingStudent = new Student("Chester the Cheetah", 7);
		Student sleepingStudent = new Student("Snorlax", 1);
		Student spookilySmartStudent = new Student("Franky N. Stein", 5);
		Student notAStudent = new Student("Scooby Doo", 0);
		
		// Make array of ICS 311 students
		Student[] students311 = {cheatingStudent, sleepingStudent, spookilySmartStudent, notAStudent};
		
		// Create ICS 311 course
		Course course3 = new Course("ICS 311", students311);
		
		// Make array of the courses
		Course[] courses = {course1, course2, course3};
		
		// Create a professor who teaches the three classes
		FairProfessor prof = new FairProfessor("Jason Leigh", courses);
		
		// Make the professor grade ALL of his students in ALL of the courses that he teaches!
		// TODO: Go to the FairProfessor class and implement the gradeAllStudents() method so that this will work.
		prof.gradeAllStudents();
		
	}

}
