/**
 * A class representation of a university course
 * You do not have to modify this class.
 * 
 * @author Camelia Lai
 *
 */
public class Course {
	
	public Student[] students; // The students taking this course
	public String courseName; // The name of the course
	
	/**
	 * A constructor for a Course object that takes in a course name and an array of students for the course
	 * 
	 * @param courseName: a String, the name to give the new Course object
	 * @param students: a Student array, the students enrolled in this new Course object
	 */
	public Course(String courseName, Student[] students) {
		this.courseName = courseName;
		this.students = students;
	}
	
	/**
	 * Sets students to a new array of students
	 * @param students: A Student array, the new array of students in this course
	 */
	public void setStudents(Student[] students) {
		this.students = students;
	}
	
	/**
	 * Returns the students in this course
	 * @return Student array students
	 */
	public Student[] getStudents() {
		return this.students;
	}
	
	/**
	 * Returns the name of this course
	 * @return String courseName
	 */
	public String getCourseName() {
		return this.courseName;
	}
	
}
