/**
 * The solution to question 4 on assignment 3
 * 
 * @author Camelia Lai
 *
 */
public class A3Q4Pattern {

	/**
	 * Prints out 5, then 4, then 3, then 2, then 1 asterisk on different rows
	 * Example of nested for loops
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// i is the row number - goes from 4 down to 0
		for (int i = 4; i >= 0; i--) {
			// j is the number of times to print * in a row, goes from 0 up to i
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
