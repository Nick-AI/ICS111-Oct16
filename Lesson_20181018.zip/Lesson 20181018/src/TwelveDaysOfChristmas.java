/**
 * A class that prints the entire lyrics of the Hawaiian 12 Days of Christmas song, using nested loops!
 * To see the full lyrics of the song for reference, go to this link: 
 * http://www.huapala.org/ChristReligious/Twelve_Days_of_Christmas.html
 * 
 * @author Camelia Lai
 *
 */
public class TwelveDaysOfChristmas {
	
	/**
	 * Main method to create an array of the tutu's gifts to you on the 12 days of Christmas and then print the entire song lyrics
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		String firstDay = "One mynah bird in one papaya tree";
		String secondDay = "Two coconuts";
		String thirdDay = "Three dried squid";
		String fourthDay = "Four flower leis";
		String fifthDay = "Five big fat pigs";
		String sixthDay = "Six hula lessons";
		String seventhDay = "Seven shrimps a-swimming";
		String eighthDay = "Eight ukuleles";
		String ninthDay = "Nine pounds of poi";
		String tenthDay = "Ten cans of beer";
		String eleventhDay = "Eleven missionaries (yum yum)";
		String twelfthDay = "Twelve televisions";
		
		// Makes an array that contains what your tutu gave you on each of the 12 days of Christmas
		String[] twelveDays = {
			firstDay,
			secondDay,
			thirdDay,
			fourthDay,
			fifthDay,
			sixthDay,
			seventhDay,
			eighthDay,
			ninthDay,
			tenthDay,
			eleventhDay,
			twelfthDay
		};
		
		// This should print out the lyrics to the entire song, after you have completed the printTwelveDausXmas method.
		printTwelveDaysXmas(twelveDays);

	}
	
	/**
	 * Prints out the full song lyrics using nested loops.
	 * 
	 * @param twelveDays: a String array containing the gifts that you got on the 12 days of Xmas
	 */
	public static void printTwelveDaysXmas(String[] twelveDays) {
		
		//TODO: First make an outer loop that iterates through the day number.
		// In the outer loop:
		// Print "Numbah <day number> day of Christmas, my tutu gave to me:"
		// Make an inner loop that prints everything in the array starting from the current day down to the first day.
		// Example: on day 3, we print Three dried squid, two coconuts, and one mynah bird in one papaya tree (day 3, day 2, day 1)
		// HINT 1: Don't forget that array indexes start at 0, so you need to account for this when printing the day number.
		// 		for example, "Numbah 0 day of Christmas..." seems a little bit off
		// HINT 2: Remember: System.out.print prints things on the same line. System.out.println starts a new line. 
		
	
	}

}
