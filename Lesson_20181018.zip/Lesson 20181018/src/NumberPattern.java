/**
 * A class that just prints numbers in a pattern as an example of using nested loops
 * 
 * @author Camelia Lai
 *
 */
public class NumberPattern {

	public static void main(String[] args) {
		
		printNumbers(5);
		printNumbers(10);

	}
	
	/**
	 * Print numbers in a pattern like this
	 * 1
	 * 12
	 * 123
	 * 1234
	 * 12345
	 * 
	 * @param number: an int, the highest number that the pattern goes up to
	 */
	public static void printNumbers(int number) {
		// The outer loop controls the highest number to print, increasing until it reaches number. 
		// i is the highest number to print on each row!
		for (int i = 1; i <= number; i++) {
			// The inner loop prints numbers from 1 up to i (the highest number to print).
			for (int j = 1; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}

}
