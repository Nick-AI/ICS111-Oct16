/**
 * A class representation of a professor that grades students FAIRLY based on their exam scores.
 * I have modified this class from last time!
 * 
 * @author Camelia Lai
 *
 */
public class FairProfessor {
	
	public String name; // The professor's name
	
	public Course[] courses; // The courses that the professor teaches.
	
	/**
	 * A constructor that takes in the name for the new professor object and an array of courses taught by the professor
	 * 
	 * @param name: a String, the professor's name
	 * @param courses: a Course array, the courses this professor teaches
	 */
	public FairProfessor(String name, Course[] courses) {
		this.name = name;
		this.courses = courses;
	}
	
	/**
	 * Returns the name of the professor 
	 * 
	 * @return String name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Gives a single Student object a grade, based on the Student's exam score
	 * 
	 * @param stu: a Student object to be graded by this professor
	 */
	public void gradeStudentFairly(Student stu) {
		int studentScore = stu.getExamScore();
		switch(studentScore) {
		case 5:
			stu.setGrade("A");
			break;
		case 4:
			stu.setGrade("B");
			break;
		case 3:
			stu.setGrade("C");
			break;
		case 2:
			stu.setGrade("D");
			break;
		case 1:
			stu.setGrade("F");
			break;
		default:
			stu.setGrade("H");
		}
	}
	
	/**
	 * Grades ALL students in ALL courses that this professor teaches.
	 */
	public void gradeAllStudents() {
		// TODO: 1) For each course that this professor teaches, print "<prof's name> is grading <course name> students."
		//			Then for each student in that course, print:
		//			<prof's name> gave <student's name> a <student's grade>
		// HINT 1: this will be super easy if you use a for each loop!
		// HINT 2: call the gradeStudentFairly method to grade each student in each course.
	}
	
}
