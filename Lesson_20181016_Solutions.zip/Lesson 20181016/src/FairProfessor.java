/**
 * A class representation of a professor that grades students FAIRLY based on their exam scores.
 * 
 * @author Camelia Lai
 *
 */
public class FairProfessor {
	
	// TODO 1) Make a member variable called name which is a String (the professor's name)
	public String name;
	
	// TODO 2) Make a constructor that takes in a String, the name of the new FairProfessor object.
	public FairProfessor(String name) {
		this.name = name;
	}
	
	// TODO 3) Make a get method for the professor's name
	public String getName() {
		return this.name;
	}
	
	// TODO 4) Make a void method called gradeStudentFairly that takes in a Student object and
	// - Gets the student's score and saves it in a variable
	// - Gives the student a grade based on this criteria:
		// A if they got a 5
		// B if they got a 4
		// C if they got a 3
		// D if they got a 2
		// F if they got a 1
		// H if they got anything else
	public void gradeStudentFairly(Student stu) {
		int studentScore = stu.getExamScore();
		switch(studentScore) {
		case 5:
			stu.setGrade("A");
			break;
		case 4:
			stu.setGrade("B");
			break;
		case 3:
			stu.setGrade("C");
			break;
		case 2:
			stu.setGrade("D");
			break;
		case 1:
			stu.setGrade("F");
			break;
		default:
			stu.setGrade("H");
		}
	}
	
	

}
