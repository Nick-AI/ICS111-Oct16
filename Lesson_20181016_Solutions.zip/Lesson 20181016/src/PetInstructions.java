/**
 * You are leaving your house for a long time, and somebody needs to take care of your pet.
 * Give them instructions for taking care of your pet, depending on what kind of animal the pet is.
 * 
 * @author Camelia Lai
 *
 */
public class PetInstructions {
	
	// TODO: Change this line! Use the constructor that takes in a String type, and give your pet a type.
	// !!!!!!!!! Please note - the previous code was wrong! myPet must be accessible by all methods in the entire class, not just main.
	// I moved myPet outside of the main method, and changed it to a public static variable (meaning that it can be used by the ENTIRE class.)
	public static Animal myPet = new Animal("pony"); // Now that the animal has they type "Dog", the instructions should tell me to give it a walk
	
	// I have added a second pet, just for fun
	public static Animal mySecondPet = new Animal("fish");
	
	// I have also added a third nonexistent pet just for fun
	public static Animal myNonexistentPet = new Animal("unicorn");
	
	/**
	 * The main method
	 * Prints the instructions for each pet.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// When you are done, run the program and see if it prints the correct instruction for your pet.
		instructions(myPet);
		
		// Instructions for the second pet
		instructions(mySecondPet);
		
		// Instructions for the third pet
		instructions(myNonexistentPet);

	}
	
	/**
	 * Prints the instructions for taking care of your pet, depending on what kind of animal it is.
	 * @param pet: an Animal object.
	 */
	public static void instructions(Animal pet) {
		// TODO: Complete this method to print the instructions for taking care of your animal depending on its type.
		// Dogs should be walked.
		// Cats should be fed.
		// Birds should be whistled at.
		// Rabbits should be given lettuce.
		// Fish should have their tank water changed.
		// Ponies should have their hair brushed.
		// Pet plants (some people consider them animal pets) should be watered and given some sun.
		// If the pet's type isn't listed, print "I don't know what to do with your animal."
		// USE A SWITCH STATEMENT
		// Hint 1: Get the animal's type first and assign it to a variable. 
		// Hint 2: The methods in the Animal class already print something.
		String petType = pet.getType();
		switch(petType) {
			case "dog": 
				pet.walk();
				break;
			case "cat": 
				pet.feed();
				break;
			case "bird":
				pet.whistleAtIt();
				break;
			case "rabbit":
				pet.giveItLettuce();
				break;
			case "fish":
				pet.changeWater();
				break;
			case "pony":
				pet.brush();
				break;
			case "plant": 
				pet.water();
				break;
			default:
				System.out.println("I don't know what to do with your animal.");
		}
	}
}
